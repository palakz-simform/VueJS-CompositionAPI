<template>
    <div>
        <form autocomplete="off">
            <div class="login-form">
                <div class="heading">
                    <h1>Login Form</h1>
                </div>
                <!-- Car Add/Edit Form -->

                <div class="form">
                    <div class="row">
                        <label for="email">Email:</label>
                        <input type="email" v-model="email" id="email" @input="checkEmail">
                        <div v-show="error_msg_email" class="error">{{ error_msg_email }}</div>
                    </div>
                    <div class="row row-password">
                        <label for="password">Password:</label>
                        <input type="password" v-model="password" id="password" @input="checkPassword">
                        <div v-show="error_msg_password" class="error">{{ error_msg_password }}</div>
                    </div>
                    <div class="row row-button">
                        <button @click.prevent="login()" class="submit">Login</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</template>

<script setup>
import { mapActions } from 'pinia'
import { ref } from 'vue'
import { useUserStore } from '../stores/user'
const store = useUserStore()

const error_msg_email = ref("")
const error_msg_password = ref("")
const email = ref("")
const password = ref("")
const ref_email = ref(null)

function clearError(error) {
    [`error_msg_${error}`].value = "";
}
function getUserData() {
    return {
        email: email.value,
        password: password.value
    }
}
function login() {
    checkEmail(),
        checkPassword()
    if (checkEmail() && checkPassword()) {
        const data = getUserData()
        store.logInUser(data)
    }
}

function checkEmail() {
    if (email.value === "") {
        const msg = "**Please enter email**"
        showError("email", msg)
        return false;
    } else if (email.value !== "") {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email.value)) {
            const msg = "**Please enter valid email**"
            showError("email", msg)
            return false;
        }
        clearError("email")
        return true;
    }
    this.clearError("email")
    return true;
}
function checkPassword() {
    if (password.value === "") {
        const msg = "**Please enter password**"
        showError("password", msg)
        return false;
    } else if (password.value !== "") {
        const passRegex = /^(?=.*\d)(?=.*[!@#$%^&*])[a-zA-Z\d!@#$%^&*]{8,12}$/;
        if (!passRegex.test(password)) {
            const msg = "**Password must be 8-12 characters, 1 number, 1 special character**"
            showError("password", msg)
            return false;
        }
        clearError("password")
        return true
    }
    clearError("password")
    return true
}
function showError(error, msg) {
    console.log(error)
    error_msg_[error].value = msg
}


</script>

<style src="../../public/style.css" scoped></style>
